var args = arguments[0] || {};

///////////function////////////
var getData = function (){
	xhr.get("http://freegeoip.net/json/", onSuccessCallback, onErrorCallback, { ttl: 5 });
};

var onSuccessCallback = function(e) {
	// Handle your request in here
	// the module will return an object with two properties
	// data (the actual data retuned
	// status ('ok' for normal requests and 'cache' for requests cached
	
	var geo = JSON.parse(e.data);
};

var onErrorCallback = function(e) {
	alert('no cache and connection lost');
	// Handle your errors in here
};

var P = function (densityPixels) {
	densityPixels = densityPixels*Ti.Platform.displayCaps.platformWidth/160;
    return densityPixels*Ti.Platform.displayCaps.dpi/160;
};

var createScrollableGridView = function (params) {
    var _p = function (densityPixels) {
    	densityPixels = densityPixels*Ti.Platform.displayCaps.platformWidth/160;
        return densityPixels*Ti.Platform.displayCaps.dpi/160;
    };
 
    var view = Ti.UI.createScrollView({
        scrollType: "vertical",
        cellWidth: (params.cellWidth)?params.cellWidth: _p(95),
        cellHeight: (params.cellHeight)?params.cellHeight: _p(95), 
        xSpacer: (params.xSpacer)?params.xSpacer: _p(3),
        ySpacer: (params.ySpacer)?params.ySpacer: _p(3),
        xGrid: (params.xGrid)?params.xGrid:3,
        data: params.data
    });
 
    var objSetIndex = 0;
    var yGrid = view.data.length/view.xGrid;
 
    for (var y=0; y<yGrid; y++){
        var row = Ti.UI.createView({
            layout: "horizontal",
            focusable: false,
            top: y*(view.cellHeight+(view.ySpacer)),
            height: view.cellHeight+(view.ySpacer),
        });        
 		console.log(view.cellWidth);
        for (var x=0; x<view.xGrid; x++){
            if(view.data[objSetIndex]){
                var thisView = Ti.UI.createView({
                    left: view.ySpacer,
                    height: view.cellHeight,
                    width: view.cellWidth,
                });
                thisView.add(view.data[objSetIndex]);
                row.add(thisView);
                objSetIndex++;
           }
        }
        view.add(row);
    }
 
    return view;
};

//////////////eventListener///////////
Ti.App.addEventListener('Ti:table_refresh', getData);

//////////////initialize///////////
getData();

var iconNums = 1;
var newIcon = function(color) {
    var v = Ti.UI.createView({
        width:P(32),
        height:P(32),
        backgroundColor: (color)?color: "#d85a1a"
    });
    v.add(Ti.UI.createLabel({
        text: iconNums++
    }));
    return v;
};
 
var dataR = [];
for (var i=0; i<24; i++) {dataR.push(newIcon());}

$.homepage.add(createScrollableGridView({
    data: dataR,
    cellWidth: P(32),
    cellHeight: P(32),
    xSpacer: P(1), //Space in between two columns
    ySpacer: P(1), //Space in between two rows
    xGrid: 3 //Number of columns
}));
