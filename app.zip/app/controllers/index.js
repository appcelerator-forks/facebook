$.win.open();
//define menu title and controller
var menu = [{id: 0, title: "Homepage", controller: 's_home'}, {id: 1, title: "Category", controller: 's_category'}, {id: 2, title: "Search", controller: 's_search'}];

///////////function////////////
//function for slide to the page
function goSlide(event){
	var index = event.source.mod;	
	var arrViews = $.scrollableView.getViews();
	
	moveHoverTo(index);
	setTitle(index);
	
	$.scrollableView.scrollToView(arrViews[index]);
}

//update title when move to next slide
function setTitle(index){
	$.title.text = menu[index]['title'];
}

//move Hover pointer
function moveHoverTo(index){
	var moveTo = Ti.UI.createAnimation({
	    left: (index*80)+'dp',
	    duration : 100,
	});
	
	$.hover.animate(moveTo);
}

//when scrollend event fire, move the hover to correct place. 
function scrollend(event){
	moveHoverTo(event.currentPage);
	if(event.currentPage == 0){
		Ti.App.fireEvent('Ti:table_refresh');
	}
}

//////////////eventListener///////////
$.scrollableView.addEventListener("scrollend", scrollend);
